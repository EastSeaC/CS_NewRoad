﻿using System.Windows;
using System.Diagnostics;
using System.Windows.Controls;
using System.Collections.Specialized;
using System.IO;


namespace Warband
{

    /// <summary>76767
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            WinPosition();
        }

        public void WinPosition()
        {

            Top = 0;
            Left = 783 - ActualWidth;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // 这里是要调用的可执行文件的文件夹目录
            string targetPath = string.Format(myPath.PySourcePath);

            // Process:提供对本地和远程进程的访问并使你能够启动和停止本地系统进程
            Process process = new Process();

            // 初始化可执行文件的一些基础信息
            process.StartInfo.WorkingDirectory = targetPath; // 初始化可执行文件的文件夹信息
            process.StartInfo.FileName = "build_module.bat"; // 初始化可执行文件名

            // 当我们需要给可执行文件传入参数时候可以设置这个参数
            // "para1 para2 para3" 参数为字符串形式，每一个参数用空格隔开
            //process.StartInfo.Arguments = "para1 para2 para3";
            process.StartInfo.UseShellExecute = true;        // 使用操作系统shell启动进程

            // 启动可执行文件
            process.Start();
            process.Close();
        }




        public void GetAllDirList(string strBaseDir)
        {
            DirectoryInfo di = new DirectoryInfo(strBaseDir);
            //添加当前目录的文件
            AddFiles(di);

            DirectoryInfo[] diA = di.GetDirectories();
            foreach (DirectoryInfo i in diA)
            {
                //注意：递归了。逻辑思维正常的人应该能反应过来
                GetAllDirList(i.FullName);
            }


        }

        public void AddFiles(DirectoryInfo di)
        {
            FileInfo[] t = di.GetFiles("*.py");

            foreach (FileInfo j in t)
            {
                _ = Set.FilePath.Add(j.FullName);
            }

        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            Conf.IsToolOpen = false;
        }

        public void OpenFile(string path)
        {

            if (File.Exists(path))
            {
                Process process = new Process();
                process.StartInfo.UseShellExecute = false;
                process.StartInfo.WorkingDirectory = Path.GetDirectoryName(path);
                process.StartInfo.Arguments = Path.GetFileName(path);
                process.StartInfo.FileName = @" E:\Program Files\Notepad++\notepad++.exe";
                process.StartInfo.WindowStyle = ProcessWindowStyle.Maximized;
                process.Start();
                process.Close();


            }
            else
            {
                MessageBox.Show("文件不存在");
            }
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cbox_1.SelectedIndex > -1)
            {
                if (Set.lastIndex != cbox_1.SelectedIndex)
                {

                    Set.lastIndex = cbox_1.SelectedIndex;
                }
                string a = cbox_1.SelectedValue.ToString();
                a = a.Replace("System.Windows.Controls.ComboBoxItem: ", "");

                cbox_2.Items.Clear();
                foreach(var i in Set.FilePath)
                {
                    if (i.Contains(a))
                    {
                        cbox_2.Items.Add(Path.GetFileNameWithoutExtension(i));
                    }
                }
            }

        }

        private void cbox_2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cbox_2.SelectedIndex > -1)
            {
                string a = cbox_2.SelectedValue.ToString();
                a = a.Replace("System.Windows.Controls.ComboBoxItem: ", "");
                foreach (var i in Set.FilePath)
                {
                    if (i.Contains(a))
                    {
                        OpenFile(i);
                        return;
                    }
                }
            }

        }

        private void OpenWarband(object sender, RoutedEventArgs e)
        {
            var x = myPath.warbandExePath;
            if (File.Exists(x))
            {
                Process process = new Process();
                process.StartInfo.UseShellExecute = false;
                process.StartInfo.FileName = x;
                process.StartInfo.WindowStyle = ProcessWindowStyle.Maximized;
                process.Start();
                process.Close();


            }
            else
            {
                MessageBox.Show("文件不存在");
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetAllDirList(myPath.PySourcePath);
            StringCollection vs = new StringCollection();
            foreach (string i in Set.FilePath)
            {
                string p = Path.GetFileNameWithoutExtension(i);
                p = p.Substring(0, p.IndexOf("_") + 1);

                if (!vs.Contains(p))
                {
                    _ = vs.Add(p);
                }
                //cbox_2.Items.Add(Path.GetFileNameWithoutExtension(j.FullName));
            }
            foreach(var i in vs)
            {
                cbox_1.Items.Add(i);
            }
        }
    }


}

