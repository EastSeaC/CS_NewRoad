﻿using System;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace Warband.Pages
{

    /// <summary>
    /// Page1.xaml 的交互逻辑
    /// </summary>
    public partial class Page1 : Page
    {
        //public delegate void DeleTest();

        //public static event Delegate TestEvent;

        public StringBuilder brfNames = new StringBuilder();

        public Page1()
        {
            InitializeComponent();
        }

        public void StatusDisplaySuccessful()
        {
            Limit window = (Limit)Limit.GetWindow(this);
            window.status1.Text = "添加成功";
            window.CleanStatus();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {

        }



        public void AddFiles(DirectoryInfo di)
        {
            var t = di.GetFiles("*.brf");
            foreach (var j in t)
            {
                brfs.Items.Add(j.FullName);
                brfNames.Append("load_mod_resource = " + Path.GetFileNameWithoutExtension(j.FullName) + "\n");
            }
            t = di.GetFiles("*.dds");
            foreach (var j in t)
            {
                ddss.Items.Add(j.FullName);
            }
        }

        public void GetAllDirList(string strBaseDir)
        {
            DirectoryInfo di = new DirectoryInfo(strBaseDir);
            //添加当前目录的文件
            AddFiles(di);

            DirectoryInfo[] diA = di.GetDirectories();
            foreach (var i in diA)
            {
                //注意：递归了。逻辑思维正常的人应该能反应过来
                GetAllDirList(i.FullName);
            }


        }

        private void UIElement_OnDrop(object sender, DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);

            foreach (var i in files)
            {
                if (File.Exists(i))
                {
                    if (i.Contains(".brf"))
                    {
                        brfs.Items.Add(i);
                        brfNames.Append("load_mod_resource = " + Path.GetFileNameWithoutExtension(i) + "\n");
                    }
                    else
                    {
                        ddss.Items.Add(i);
                    }
                }
                else
                {
                    GetAllDirList(i);
                }
            }

        }

        public void AddTokenToIni()
        {

            string a = myPath.modPath + "module.ini";
            StreamReader streamReader = new StreamReader(a);
            string[] vs = streamReader.ReadToEnd().Replace("\r", "").Split('\n');
            bool ax = true;

            streamReader.Dispose();

            foreach (var i in vs)
            {
                if (i.Contains("East_Sea_End"))
                {
                    ax = false;
                }
            }
            if (ax)
            {
                vs[vs.Length - 1] = "#East_Sea_End\n" + vs[vs.Length - 1];
            }

            StreamWriter streamWriter = new StreamWriter(a);

            foreach (var i in vs)
            {
                if (i.Contains("East_Sea_End"))
                {
                    streamWriter.WriteLine(brfNames.ToString().Trim());
                }

                streamWriter.WriteLine(i);
            }
            streamWriter.Flush();
            streamWriter.Dispose();
            brfNames.Clear();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ddss.Items.Clear();
            brfNames.Clear();
            brfs.Items.Clear();
        }


        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var vs = brfs.Items;
            foreach (var i in vs)
            {
                File.Copy(i.ToString(), myPath.BrfPath + Path.GetFileName(i.ToString()), true);
            }

            vs = ddss.Items;
            foreach (var i in vs)
            {
                File.Copy(i.ToString(), myPath.DdsPath + Path.GetFileName(i.ToString()), true);
            }
            AddTokenToIni();

            StatusDisplaySuccessful();
        }

        private void locations_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
