﻿using AppUtility;
using MahApps.Metro.Controls;
using System;
using System.Collections.Specialized;
using System.ComponentModel;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
namespace Warband
{
    public class myPath 
    {
        public static string modPath { get; set; }
        public static string ModPath
        {
            get => warbandPath + modPath;
            set => ModPath = value;
        }

        public static string pySourcePath { get; set; }
        public static string PySourcePath
        {
            get => ModPath + pySourcePath + @"\";
            set => PySourcePath = value;
        }

        public static string BrfPath => modPath + @"Resource\";
        public static string DdsPath => modPath + @"Textures\";
        public static string warbandPath;


        public static string warbandExePath
        {
            get => warbandPath + "\\mb_warband.exe";
            set => warbandExePath = value;
        }


    }

    public class Conf
    {
        public static bool IsToolOpen { get; set; } = false;
    }
    /// <summary>
    /// Interaction logic for Limit.xaml
    /// </summary>
    public partial class Limit : MetroWindow
    {

        public Limit()
        {
            InitializeComponent();
            //var a= new GWindowx();
            //a.InitialTray();
        }

        private void lbox1_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (frame1.CanGoBack)
            {
                _ = frame1.RemoveBackEntry();
            }

            _ = frame1.Navigate(new Uri(@"\Pages\" + (sender as ListBoxItem).Tag.ToString() + ".xaml", UriKind.Relative));
        }

        private void MetroWindow_Loaded(object sender, RoutedEventArgs e)
        {
            subWindows.ConfigurationWin configuration = new subWindows.ConfigurationWin();
            _ = configuration.ShowDialog();
        }

        public void CleanStatus()
        {
            DispatcherTimer dispatcher = new DispatcherTimer
            {
                //after 10 seconds .clear the stateBoard
                Interval = new TimeSpan(0, 0, 5),
                IsEnabled = true,

            };
            dispatcher.Tick += new EventHandler(setState);
            dispatcher.Start();

            void setState(object sender, EventArgs e)
            {
                status1.Text = "";
                dispatcher.Stop();
            }

        }

        private void Mei2_1_Click(object sender, RoutedEventArgs e)
        {
            if (!Conf.IsToolOpen)
            {

                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                Conf.IsToolOpen = true;
            }
        }

        private void meie_Click(object sender, RoutedEventArgs e)
        {
            subWindows.ConfigurationWin configuration = new subWindows.ConfigurationWin();
            configuration.ShowDialog();
        }
    }



}

namespace AppUtility
{
    public class IniHelper
    {
        // 声明INI文件的写操作函数 WritePrivateProfileString()
        [System.Runtime.InteropServices.DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

        // 声明INI文件的读操作函数 GetPrivateProfileString()
        [System.Runtime.InteropServices.DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, System.Text.StringBuilder retVal, int size, string filePath);

        // 声明INI文件的 获取某个节点Section 下的所有Key 和value 并且以 "Key=Value" 的形式返回
        [System.Runtime.InteropServices.DllImport("kernel32")]
        private static extern int GetPrivateProfileSection(string lpAppName, byte[] lpReturnedString, int nSize, string lpFileName);

        [System.Runtime.InteropServices.DllImport("kernel32")]
        private static extern int GetPrivateProfileSectionNames(byte[] lpszReturnBuffer, int nSize, string lpFileName);

        public bool is_new_file = false;
        private string sPath = null;

        public IniHelper(string path)
        {
            //判断相对路径
            if (!path.Contains(":"))
            {
                //处理后缀名
                if (!path.Contains(".ini"))
                {
                    path += ".ini";
                }

                path = AppDomain.CurrentDomain.BaseDirectory + "\\" + path;
            }

            if (!File.Exists(path))
            {
                is_new_file = true;
                _ = File.Create(path);
            }
            sPath = path;
        }

        public IniHelper()
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + "\\default_config.ini";
            if (!File.Exists(path))
            {
                is_new_file = true;
                _ = File.Create(path);
            }
            sPath = path;
        }

        public void WriteValue(string section, string key, string value)
        {
            // section=配置节，key=键名，value=键值，path=路径
            _ = WritePrivateProfileString(section, key, value, sPath);
        }

        // 删除整个 节 section
        public void DeleteSection(string section)
        {
            WritePrivateProfileString(section, null, null, sPath);
        }
        // 删除整个 键 Key
        public void DeleteKey(string section, string key)
        {
            WritePrivateProfileString(section, key, null, sPath);
        }
        //判断某个节点section是否存在
        public bool isSectionExist(string section)
        {
            if (is_new_file)
                return false;
            if (!GetINISectionNames().Contains(section))
                return false;
            return true;
        }

        public string ReadValue(string section, string key)
        {
            // 每次从ini中读取多少字节
            System.Text.StringBuilder temp = new System.Text.StringBuilder(255);
            // section=配置节，key=键名，temp=上面，path=路径
            GetPrivateProfileString(section, key, "", temp, 255, sPath);
            return temp.ToString();
        }

        public StringCollection GetINISection(string section)
        {
            StringCollection items = new StringCollection();
            byte[] buffer = new byte[32768];
            int bufLen = GetPrivateProfileSection(section, buffer, buffer.GetUpperBound(0), sPath);
            if (bufLen > 0)
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < bufLen; i++)
                {
                    if (buffer[i] != 0)
                    {
                        _ = sb.Append((char)buffer[i]);
                    }
                    else
                    {
                        if (sb.Length > 0)
                        {
                            _ = items.Add(sb.ToString());
                            sb = new StringBuilder();
                        }
                    }
                }
            }
            return items;
        }

        public StringCollection GetINISectionNames()
        {
            StringCollection items = new StringCollection();
            byte[] buffer = new byte[32768];
            int bufLen = GetPrivateProfileSectionNames(buffer, buffer.GetUpperBound(0), sPath);
            if (bufLen > 0)
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < bufLen; i++)
                {
                    if (buffer[i] != 0)
                    {
                        _ = sb.Append((char)buffer[i]);
                    }
                    else
                    {
                        if (sb.Length > 0)
                        {
                            _ = items.Add(sb.ToString());
                            sb = new StringBuilder();
                        }
                    }
                }
            }
            return items;
        }

    }


}
