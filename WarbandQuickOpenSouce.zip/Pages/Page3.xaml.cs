﻿using System;
using System.Data;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Warband.Pages
{
    /// <summary>
    /// Page3.xaml 的交互逻辑
    /// </summary>
    public partial class Page3 : Page
    {
        private string[] textx = { "等级", "力量", "敏捷", "智力", "魅力" };
        private string[] vs;
        public Page3()
        {
            InitializeComponent();
        }

        //读取文件
        public void ReadHeaderFile(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
            {
                throw new ArgumentException($"“{nameof(path)}”不能为 null 或空白。", nameof(path));
            }

            if (File.Exists(path))
            {

                StreamReader streamReader = new StreamReader(path);
                vs = streamReader.ReadToEndAsync().Result.Trim().Split('\n');

            }
            else
            {
                _ = MessageBox.Show(path + "\n文件不存在");
            }

        }

        public void AddFlag()
        {
            DataTable dataTable = new DataTable("my_dtable");

            DataColumn attribute = new DataColumn("属性")
            {
                DataType = Type.GetType("System.String"),
                ReadOnly = true,
            };

            dataTable.Columns.Add(attribute);


            DataRow row = dataTable.NewRow();
            foreach (string i in textx)
            {
                row = dataTable.NewRow();
                row[0] = i;
                dataTable.Rows.Add(row);
            }

            datagrid2.DataContext = dataTable;

            dataTable = new DataTable("skill_dtable");
            DataColumn skill = new DataColumn("技能")
            {
                DataType = typeof(string),
                ReadOnly = true,
            };
            dataTable.Columns.Add(skill);
            //读取文件
            StreamReader streamReader = new StreamReader(@"../data/skill_name.txt");
            string[] x = streamReader.ReadToEnd().Trim().Split('\n');
            foreach (var i in x)
            {
                string t = i.Trim();
                row = dataTable.NewRow();
                row[0] = i;
                dataTable.Rows.Add(row);
            }
            datagrid3.DataContext = dataTable;


        }

        public void AddSkins()
        {

        }



        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            AddFlag();
        }

        private void DataGridRow_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {

            DataGridRow item = (DataGridRow)sender;
            FrameworkElement objElement = datagrid1.Columns[0].GetCellContent(item);
            if (objElement != null)
            {
                CheckBox checkbox = (CheckBox)objElement;
                checkbox.IsChecked = !checkbox.IsChecked;
            }

        }

        private void pox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex re = new Regex("[^0-9]+");
            e.Handled = re.IsMatch(e.Text);

        }

        public string readDatagrid2()
        {
            string x = "";
            string[] match = { "level(", "str_", "agi_", "int_", "cha_" };
            for (int k = 0; k < datagrid2.Items.Count; k++)
            {
                //首先获取DataGridTemplateColumn所在列
                DataGridTemplateColumn tempColumn = datagrid2.Columns[0] as DataGridTemplateColumn;
                //然后获取DataGridTemplateColumn单元格元素
                FrameworkElement element = datagrid2.Columns[0].GetCellContent(datagrid2.Items[k]);

                //把单元格元素转换为相应的控件，再从该控件中取值
                TextBox ck = (TextBox)tempColumn.CellTemplate.FindName("pox", element);
                if (k is 0)
                {
                    if (ck.Text.Length > 0)
                    {
                        x = match[k] + ck.Text + ")";
                    }
                    else
                    {
                        x = match[k] + "1)";
                    }

                }
                else
                {
                    x += match[k];
                    bool v = ck.Text.Length > 0 && int.Parse(ck.Text) > 3;
                    if (v)
                    {
                        x += ck.Text;
                    }
                    else
                    {
                        x += "3";
                    }

                }

                if (k < 4)
                {
                    x += "|";
                }

            }
            return x;
        }
        // need to modify
        public string readSkill()
        {
            string x = "";
            string[] match = { "level(", "str_", "agi_", "int_", "cha_" };
            int count = datagrid3.Items.Count;
            for (int k = 0; k < count; k++)
            {
                //首先获取DataGridTemplateColumn所在列
                DataGridTemplateColumn tempColumn = datagrid3.Columns[0] as DataGridTemplateColumn;
                //然后获取DataGridTemplateColumn单元格元素
                FrameworkElement element = datagrid3.Columns[0].GetCellContent(datagrid3.Items[k]);

                //把单元格元素转换为相应的控件，再从该控件中取值
                TextBox ck = (TextBox)tempColumn.CellTemplate.FindName("pox", element);

                {
                    x += match[k];
                    bool v = ck.Text.Length > 0 && int.Parse(ck.Text) > 3;
                    if (v)
                    {
                        x += ck.Text;
                    }
                    else
                    {
                        x += "3";
                    }

                }

                if (k < count - 1)
                {
                    x += "|";
                }

            }
            return x;
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string x = readDatagrid2();
            MessageBox.Show(x);



        }
    }
}



