﻿using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System;
using Drawing = System.Drawing;


namespace Warband.Pages
{

    /// <summary>
    /// Page2.xaml 的交互逻辑
    /// </summary>
    public partial class Page2 : Page
    {
        ListViewItem listViewItem;
        public Page2()
        {
            InitializeComponent();
            tb2.Focus();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            string a = tb2.Text;
            a = Regex.Replace(a, @"\s", "");
            StringBuilder res = new StringBuilder();
            for (int i = 0; i < a.Length; i++)
            {
                if (Regex.IsMatch(a[i].ToString(), "^[^\x00-\xFF]"))
                {
                    if (i > 0 && Regex.IsMatch(a[i - 1].ToString(), "[\x00-\xFF]"))
                    {
                        res.Append(" " + a[i] + " ");
                    }
                    else
                        res.Append(a[i] + " ");
                }
                else
                    res.Append(a[i].ToString());
            }
            tb1.Text = res.ToString().Trim();
            Clipboard.SetText(tb1.Text);

            // 添加到记录stack

            listViewItem = new ListViewItem()
            {
                Content = tb2.Text,
                Tag = tb1.Text,
            };
            odd.Items.Add(listViewItem);
        }

        private void tb2_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key is Key.Enter)
            {
                Button_Click(sender, e);
                Clipboard.SetText(tb1.Text);
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            tb1.Clear();
            tb2.Clear();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            tb2.Text = Clipboard.GetText();
            Button_Click(sender, e);
        }

        private void DelectPlayEvent(object sender, RoutedEventArgs e)
        {
            if (odd.SelectedIndex > -1)
            {

                tb2.Text = (odd.SelectedItem as ListViewItem).Content.ToString();
            }
            //Button_Click(sender, e);
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            odd.Items.Clear();
        }
    }

    


}
