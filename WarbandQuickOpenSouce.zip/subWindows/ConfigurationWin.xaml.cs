﻿using AppUtility;
using MahApps.Metro.Controls;
using Microsoft.WindowsAPICodePack.Dialogs;
using System;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Threading;
using Brush = System.Windows.Media.Brush;
using Color = System.Windows.Media.Color;

namespace Warband.subWindows
{

    /// <summary>
    /// Interaction logic for ConfigurationWin.xaml
    /// </summary>
    public partial class ConfigurationWin : MetroWindow
    {
        private readonly IniHelper iniHelper = new IniHelper("config.ini");
        public delegate void Testdg();
        public event Testdg TestEvent;
        public ConfigurationWin()
        {
            InitializeComponent();

        }

        private void Choose_WarbandPath(object sender, RoutedEventArgs e)
        {
            CommonOpenFileDialog dialog = new CommonOpenFileDialog
            {
                IsFolderPicker = true,//设置为选择文件夹
                InitialDirectory = iniHelper.ReadValue("Last", "warbandPath"),
            };
            CommonFileDialogResult a = dialog.ShowDialog();
            _ = Activate();
            if (a.Equals(CommonFileDialogResult.Ok))
            {
                warbandPath.Text = dialog.FileName;
            }

            dialog.Dispose();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (!Directory.Exists(warbandPath.Text))
            {
                _ = MessageBox.Show("不存在");
            }
            else
            {
                CommonOpenFileDialog dialog = new CommonOpenFileDialog
                {
                    IsFolderPicker = true,//设置为选择文件夹
                    InitialDirectory = warbandPath.Text + "\\Modules\\",
                };
                CommonFileDialogResult a = dialog.ShowDialog();
                _ = Activate();
                if (a.Equals(CommonFileDialogResult.Ok))
                {
                    string c = warbandPath.Text + "\\Modules\\" + Path.GetFileName(dialog.FileName);
                    if (Directory.Exists(c))
                    {
                        modPath.Text = "\\Modules\\" + Path.GetFileName(dialog.FileName);
                    }
                }
                dialog.InitialDirectory = warbandPath.Text;
                dialog.Dispose();
            }
        }

        private void Choose_SourcePath(object sender, RoutedEventArgs e)
        {
            if (!Directory.Exists(warbandPath.Text + modPath.Text))
            {
                _ = MessageBox.Show("不存在");
            }
            else
            {
                CommonOpenFileDialog dialog = new CommonOpenFileDialog
                {
                    IsFolderPicker = true,//设置为选择文件夹
                    InitialDirectory = warbandPath.Text + modPath.Text,
                };
                CommonFileDialogResult a = dialog.ShowDialog();
                _ = Activate();
                if (a.Equals(CommonFileDialogResult.Ok))
                {
                    pySourcePath.Text = "\\" + Path.GetFileName(dialog.FileName);
                }
                dialog.InitialDirectory = warbandPath.Text;
                dialog.Dispose();
            }
        }

        private void MetroWindow_Loaded(object sender, RoutedEventArgs e)
        {

            warbandPath.Text = iniHelper.ReadValue("Last", "warbandPath");

            DirectoryInfo c = new DirectoryInfo(iniHelper.ReadValue("Last", "modPath"));
            modPath.Text = "\\" + c.Parent + "\\" + c.Name;

            c = new DirectoryInfo(iniHelper.ReadValue("Last", "pySourcePath"));
            pySourcePath.Text = "\\" + c.Name;

        }

        private void Confirm(object sender, RoutedEventArgs e)
        {

            myPath.warbandPath = warbandPath.Text;
            myPath.modPath = modPath.Text;
            myPath.pySourcePath = pySourcePath.Text;

            IniHelper iniHelper = new IniHelper("config.ini");
            iniHelper.WriteValue("Last", "warbandPath", myPath.warbandPath);
            iniHelper.WriteValue("Last", "modPath", myPath.ModPath);
            iniHelper.WriteValue("Last", "pySourcePath", myPath.PySourcePath);

            TestEvent?.Invoke();
            //_ = Dispatcher.BeginInvoke(DispatcherPriority.Normal, TestEvent);

            Close();
        }

        private void pySoucePath_GotKeyboardFocus(object sender, System.Windows.Input.KeyboardFocusChangedEventArgs e)
        {
            (sender as System.Windows.Controls.TextBox).BorderBrush = GetRandomColor();
        }

        public Brush GetRandomColor()
        {
            Random random = new Random();
            byte a = (byte)random.Next(0, 255);
            byte b = (byte)random.Next(0, 255);
            byte c = (byte)random.Next(0, 255);
            return new SolidColorBrush(Color.FromRgb(a, b, c));

        }
    }
}


namespace MyConverter
{
    [ValueConversion(typeof(string), typeof(string))]
    public class PathConverter : IValueConverter
    {
        //源属性传给目标属性时，调用此方法ConvertBack
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            int c = System.Convert.ToInt32(parameter);

            if (value == null)
                throw new ArgumentNullException("value can not be null");

            int index = System.Convert.ToInt32(value);
            if (index == 0)
                return "Blue";
            else if (index == 1)
                return "Red";
            else
                return "Green";
        }

        //目标属性传给源属性时，调用此方法ConvertBack
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}