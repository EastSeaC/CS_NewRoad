﻿using System;
using System.Collections.Specialized;
using System.Windows;

namespace Warband
{
    public class Set
    {
        public static StringCollection FilePath { get; set; } = new StringCollection();
        public static string prefix { get; set; }
        public static int lastIndex { get; set; } = 0;

    }
    /// <summary>
    /// App.xaml 的交互逻辑
    /// </summary>
    public partial class App : Application
    {
        private System.Threading.Mutex mutex;

        public App()
        {
            Startup += new StartupEventHandler(App_Startup);
        }

        void App_Startup(object sender, StartupEventArgs e)
        {
            mutex = new System.Threading.Mutex(true, "ElectronicNeedleTherapySystem", out bool ret);

            if (!ret)
            {
                _ = MessageBox.Show("已有一个程序实例运行");
                Environment.Exit(0);
            }

        }
    }

}

